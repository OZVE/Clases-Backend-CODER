class Carrito {
    constructor(){
        this.id = 0
        this.date = new Date()
        this.productos = {items:[]}
    }
}
module.exports = Carrito;