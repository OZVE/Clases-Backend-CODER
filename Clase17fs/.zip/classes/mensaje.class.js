class Mensaje {
    constructor(name, mensaje){
        this.id = 0
        this.date = new Date()
        this.name = name
        this.mensaje = mensaje

    }
}
module.exports = Mensaje;
